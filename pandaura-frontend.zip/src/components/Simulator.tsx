import { useState } from 'react'
import { useSimulatorStore } from '../store/simulatorStore'
import { useSyncStore } from '../store/syncStore'
import { Play, Pause, Square, SkipForward, Download, Trash2, Settings } from 'lucide-react'
import { Dialog } from './Dialog'

export function Simulator() {
  const {
    isRunning,
    isPaused,
    speed,
    logs,
    ioValues,
    currentLine,
    run,
    pause,
    resume,
    step,
    stop,
    setSpeed,
    setIOValue,
    clearLogs,
  } = useSimulatorStore()

  const { deployedLogic } = useSyncStore()
  
  // Only use ioValues from simulator - no external tag polling for simulator display
  // This ensures we show actual simulator state, not persistent database tags
  const displayValues = ioValues

  // Hyper-granular simulation settings
  const [showSettings, setShowSettings] = useState(false)
  
  const [simulatorSettings, setSimulatorSettings] = useState({
    scanTimeMs: 100,
    ioLatencyMin: 1,
    ioLatencyMax: 5,
    ioJitter: 0.5,
    computeQuota: 80,
    enableWatchdog: true,
    watchdogTimeout: 1000,
    enableDataTypeValidation: true
  })


  const handleToggleBoolean = (name: string) => {
    const currentValue = displayValues[name] as boolean
    setIOValue(name, !currentValue)
  }

  const handleSetNumeric = (name: string, value: number) => {
    setIOValue(name, value)
  }

  const downloadLogs = () => {
    const logContent = logs
      .map(log => `[${log.timestamp}] [${log.type.toUpperCase()}] ${log.message}`)
      .join('\n')
    
    const blob = new Blob([logContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `simulator-log-${new Date().toISOString()}.log`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-4">
      {/* Control Bar */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-gray-700 p-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            {!isRunning ? (
              <button
                onClick={() => deployedLogic ? run(deployedLogic.content) : run('(* No logic deployed *)')}
                disabled={!deployedLogic}
                className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                  deployedLogic 
                    ? 'bg-green-600 text-white hover:bg-green-700' 
                    : 'bg-neutral-200 dark:bg-gray-600 text-neutral-500 dark:text-gray-400 cursor-not-allowed'
                }`}
              >
                <Play className="w-4 h-4" />
                Start
              </button>
            ) : (
              <>
                {isPaused ? (
                  <button
                    onClick={resume}
                    className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                  >
                    <Play className="w-4 h-4" />
                    Resume
                  </button>
                ) : (
                  <button
                    onClick={pause}
                    className="flex items-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-md hover:bg-amber-700 transition-colors"
                  >
                    <Pause className="w-4 h-4" />
                    Pause
                  </button>
                )}
                
                <button
                  onClick={step}
                  disabled={!isPaused}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md transition-colors ${
                    isPaused
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-neutral-200 dark:bg-gray-600 text-neutral-500 dark:text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <SkipForward className="w-4 h-4" />
                  Step
                </button>

                <button
                  onClick={stop}
                  className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                >
                  <Square className="w-4 h-4" />
                  Stop
                </button>
              </>
            )}
          </div>

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm dark:text-gray-200">
              Speed:
              <select
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                className="px-2 py-1 border border-neutral-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00]"
              >
                <option value={0.5}>0.5x</option>
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={5}>5x</option>
                <option value={10}>10x</option>
              </select>
            </label>

            {currentLine && (
              <div className="px-3 py-1 bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 rounded-md text-sm font-medium">
                Line: {currentLine}
              </div>
            )}

            <div className={`px-3 py-1 rounded-md text-sm font-medium ${
              isRunning 
                ? isPaused 
                  ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300' 
                  : 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300'
                : 'bg-neutral-100 dark:bg-gray-700 text-neutral-600 dark:text-gray-300'
            }`}>
              {isRunning ? (isPaused ? 'Paused' : 'Running') : 'Stopped'}
            </div>

            <div className={`px-3 py-1 rounded-md text-sm font-medium ${
              deployedLogic 
                ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300' 
                : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300'
            }`}>
              {deployedLogic ? `Logic: ${deployedLogic.name}` : 'No Logic Deployed'}
            </div>

            <button
              onClick={() => setShowSettings(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-700 border border-neutral-300 dark:border-gray-600 text-neutral-800 dark:text-gray-200 rounded-md hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors shadow-sm"
              title="Simulator Settings"
            >
              <Settings className="w-4 h-4" />
              Settings
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* I/O Panel */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-gray-700 p-4">
          <h3 className="font-semibold mb-4 dark:text-white">I/O Panel</h3>
          
          {Object.keys(displayValues).length === 0 ? (
            <div className="text-sm text-neutral-500 dark:text-gray-400 text-center py-8">
              No variables loaded. Start the simulator to see I/O values.
            </div>
          ) : (
            <div className="space-y-4">
              {/* Boolean I/O - Auto-detect */}
              {Object.entries(displayValues).some(([_, value]) => typeof value === 'boolean') && (
                <div>
                  <div className="text-sm font-medium text-neutral-700 dark:text-gray-300 mb-2">Digital I/O</div>
                  <div className="space-y-2">
                    {Object.entries(displayValues)
                      .filter(([_, value]) => typeof value === 'boolean')
                      .map(([name, value]) => (
                        <div key={name} className="flex items-center justify-between p-2 bg-neutral-50 dark:bg-gray-700 rounded">
                          <span className="text-sm font-mono dark:text-gray-300">{name}</span>
                          <button
                            onClick={() => handleToggleBoolean(name)}
                            className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                              value
                                ? 'bg-green-600 text-white'
                                : 'bg-neutral-300 dark:bg-neutral-600 text-neutral-700 dark:text-neutral-200'
                            }`}
                          >
                            {value ? 'ON' : 'OFF'}
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {/* Numeric I/O - Auto-detect */}
              {Object.entries(displayValues).some(([_, value]) => typeof value === 'number') && (
                <div>
                  <div className="text-sm font-medium text-neutral-700 dark:text-gray-300 mb-2">Analog I/O</div>
                  <div className="space-y-3">
                    {Object.entries(displayValues)
                      .filter(([_, value]) => typeof value === 'number')
                      .map(([name, value]) => {
                        // Determine if this is a read-only output variable
                        const isOutput = name.includes('Output') || name.includes('output')
                        const isPercentage = name.includes('Level') || name.includes('Output') || name.includes('Humidity')
                        const isTemperature = name.includes('Temp') || name.includes('temp')
                        
                        const min = 0
                        const max = isPercentage ? 100 : isTemperature ? 150 : 100
                        const unit = isTemperature ? '°C' : isPercentage ? '%' : ''
                        
                        return (
                          <div 
                            key={name} 
                            className={`p-2 rounded ${isOutput ? 'bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700' : 'bg-neutral-50 dark:bg-gray-700'}`}
                          >
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-sm font-mono dark:text-gray-300">{name}</span>
                              <span className={`text-sm font-medium ${isOutput ? 'text-blue-800 dark:text-blue-300' : 'dark:text-gray-200'}`}>
                                {typeof value === 'number' ? value.toFixed(2) : value}{unit}
                              </span>
                            </div>
                            {!isOutput && (
                              <input
                                type="range"
                                min={min}
                                max={max}
                                step="0.1"
                                value={value as number}
                                onChange={(e) => handleSetNumeric(name, Number(e.target.value))}
                                className="w-full"
                              />
                            )}
                            {isOutput && (
                              <>
                                <div className="mt-1 w-full bg-neutral-200 dark:bg-gray-600 rounded-full h-2">
                                  <div 
                                    className="bg-blue-600 h-2 rounded-full transition-all"
                                    style={{ width: `${Math.min(100, Math.max(0, value as number))}%` }}
                                  />
                                </div>
                                <div className="text-xs text-neutral-600 dark:text-gray-400 mt-1">Output (read-only)</div>
                              </>
                            )}
                          </div>
                        )
                      })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Snapshot */}
          <div className="mt-4 pt-4 border-t border-neutral-200 dark:border-gray-700">
            <button
              className="w-full px-3 py-2 text-sm bg-white dark:bg-gray-700 border border-neutral-300 dark:border-gray-600 text-neutral-800 dark:text-gray-200 rounded-md hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              onClick={() => alert('Snapshot saved')}
              disabled={Object.keys(displayValues).length === 0}
            >
              Save I/O Snapshot
            </button>
          </div>
        </div>

        {/* Trace/Log Panel */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border border-neutral-200 dark:border-gray-700 p-4 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold dark:text-white">Trace Log</h3>
            <div className="flex items-center gap-2">
              <button
                onClick={downloadLogs}
                className="flex items-center gap-1 px-2 py-1 text-xs bg-white dark:bg-gray-700 border border-neutral-300 dark:border-gray-600 text-neutral-800 dark:text-gray-200 rounded hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors"
                title="Download Logs"
              >
                <Download className="w-3 h-3" />
                Export
              </button>
              <button
                onClick={clearLogs}
                className="flex items-center gap-1 px-2 py-1 text-xs bg-white dark:bg-gray-700 border border-neutral-300 dark:border-gray-600 text-neutral-800 dark:text-gray-200 rounded hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors"
                title="Clear Logs"
              >
                <Trash2 className="w-3 h-3" />
                Clear
              </button>
            </div>
          </div>

          <div className="flex-1 bg-neutral-900 text-neutral-100 rounded-md p-3 font-mono text-xs overflow-y-auto max-h-96">
            {logs.length === 0 ? (
              <div className="text-neutral-500 dark:text-gray-400">No logs yet. Start the simulator to see activity.</div>
            ) : (
              <div className="space-y-1">
                {logs.map((log) => (
                  <div key={log.id} className="flex gap-2">
                    <span className="text-neutral-500 flex-shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                    <span className={`flex-shrink-0 ${
                      log.type === 'error' ? 'text-red-400' :
                      log.type === 'warning' ? 'text-amber-400' :
                      log.type === 'tag_change' ? 'text-blue-400' :
                      log.type === 'drift' ? 'text-orange-400' :
                      log.type === 'execution' ? 'text-purple-400' :
                      'text-green-400'
                    }`}>
                      [{log.type.toUpperCase()}]
                    </span>
                    <span>{log.message}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Breakpoint Info */}
      <div className="bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700 rounded-lg p-3">
        <div className="text-sm text-blue-900 dark:text-blue-300">
          <strong>💡 Tip:</strong> Click in the editor's left margin to set breakpoints. 
          The simulator will pause when execution reaches a breakpoint line.
        </div>
      </div>

      {/* Simulator Settings Dialog */}
      <Dialog
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        title="Simulator Configuration"
        size="xl"
      >
        <div className="space-y-8 p-6">
          {/* Performance Settings Section */}
          <div className="space-y-6">
            <div className="border-b border-neutral-200 dark:border-gray-600 pb-4">
              <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">Performance Settings</h3>
              <p className="text-sm text-neutral-600 dark:text-gray-400 mt-1">Configure scan cycle timing and resource limits</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <label className="block text-sm font-medium text-neutral-700 dark:text-gray-300">
                  Scan Time (ms)
                </label>
                <input
                  type="number"
                  min="1"
                  max="10000"
                  value={simulatorSettings.scanTimeMs}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, scanTimeMs: Number(e.target.value) }))}
                  className="w-full px-4 py-3 border border-neutral-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00] focus:border-transparent transition-colors"
                />
                <div className="text-xs text-neutral-500 dark:text-gray-400">PLC scan cycle execution time</div>
              </div>
              
              <div className="space-y-3">
                <label className="block text-sm font-medium text-neutral-700 dark:text-gray-300">
                  CPU Quota (%)
                </label>
                <input
                  type="number"
                  min="10"
                  max="100"
                  value={simulatorSettings.computeQuota}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, computeQuota: Number(e.target.value) }))}
                  className="w-full px-4 py-3 border border-neutral-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00] focus:border-transparent transition-colors"
                />
                <div className="text-xs text-neutral-500 dark:text-gray-400">Maximum CPU usage per scan cycle</div>
              </div>
            </div>
          </div>

          {/* I/O Simulation Section */}
          <div className="space-y-6">
            <div className="border-b border-neutral-200 dark:border-gray-600 pb-4">
              <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">I/O Latency Simulation</h3>
              <p className="text-sm text-neutral-600 dark:text-gray-400 mt-1">Realistic network and device response delays</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-3">
                <label className="block text-sm font-medium text-neutral-700 dark:text-gray-300">Min Latency (ms)</label>
                <input
                  type="number"
                  min="0"
                  max="1000"
                  step="0.1"
                  value={simulatorSettings.ioLatencyMin}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, ioLatencyMin: Number(e.target.value) }))}
                  className="w-full px-3 py-2.5 text-sm border border-neutral-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00] focus:border-transparent transition-colors"
                />
              </div>
              <div className="space-y-3">
                <label className="block text-sm font-medium text-neutral-700 dark:text-gray-300">Max Latency (ms)</label>
                <input
                  type="number"
                  min="0"
                  max="1000"
                  step="0.1"
                  value={simulatorSettings.ioLatencyMax}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, ioLatencyMax: Number(e.target.value) }))}
                  className="w-full px-3 py-2.5 text-sm border border-neutral-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00] focus:border-transparent transition-colors"
                />
              </div>
              <div className="space-y-3">
                <label className="block text-sm font-medium text-neutral-700 dark:text-gray-300">Jitter (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  value={simulatorSettings.ioJitter}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, ioJitter: Number(e.target.value) }))}
                  className="w-full px-3 py-2.5 text-sm border border-neutral-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00] focus:border-transparent transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Safety & Diagnostics Section */}
          <div className="space-y-6">
            <div className="border-b border-neutral-200 dark:border-gray-600 pb-4">
              <h3 className="text-lg font-semibold text-neutral-800 dark:text-white">Safety & Diagnostics</h3>
              <p className="text-sm text-neutral-600 dark:text-gray-400 mt-1">System monitoring and error detection</p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <input
                  type="checkbox"
                  id="enableWatchdog"
                  checked={simulatorSettings.enableWatchdog}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, enableWatchdog: e.target.checked }))}
                  className="mt-1 h-4 w-4 text-[#FF6A00] focus:ring-[#FF6A00] border-neutral-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700"
                />
                <div className="flex-1">
                  <label htmlFor="enableWatchdog" className="text-sm font-medium text-neutral-700 dark:text-gray-300">
                    Enable Watchdog Timer
                  </label>
                  <p className="text-xs text-neutral-500 dark:text-gray-400 mt-1">Monitors scan cycle execution time for safety</p>
                </div>
              </div>
              
              {simulatorSettings.enableWatchdog && (
                <div className="ml-8 space-y-3">
                  <label className="block text-sm font-medium text-neutral-700 dark:text-gray-300">
                    Watchdog Timeout (ms)
                  </label>
                  <input
                    type="number"
                    min="100"
                    max="60000"
                    value={simulatorSettings.watchdogTimeout}
                    onChange={(e) => setSimulatorSettings(prev => ({ ...prev, watchdogTimeout: Number(e.target.value) }))}
                    className="w-full max-w-xs px-4 py-3 border border-neutral-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#FF6A00] focus:border-transparent transition-colors"
                  />
                  <div className="text-xs text-neutral-500 dark:text-gray-400">Maximum allowed scan time before fault condition</div>
                </div>
              )}

              <div className="flex items-start space-x-4">
                <input
                  type="checkbox"
                  id="enableDataTypeValidation"
                  checked={simulatorSettings.enableDataTypeValidation}
                  onChange={(e) => setSimulatorSettings(prev => ({ ...prev, enableDataTypeValidation: e.target.checked }))}
                  className="mt-1 h-4 w-4 text-[#FF6A00] focus:ring-[#FF6A00] border-neutral-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700"
                />
                <div className="flex-1">
                  <label htmlFor="enableDataTypeValidation" className="text-sm font-medium text-neutral-700 dark:text-gray-300">
                    Enable Data Type Overflow Modeling
                  </label>
                  <p className="text-xs text-neutral-500 dark:text-gray-400 mt-1">Simulate real PLC data type limitations and overflow behavior</p>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-4 pt-6 border-t border-neutral-200 dark:border-gray-600">
            <button
              onClick={() => setShowSettings(false)}
              className="px-6 py-3 bg-white dark:bg-gray-700 border border-neutral-300 dark:border-gray-600 text-neutral-700 dark:text-gray-200 rounded-lg hover:bg-neutral-50 dark:hover:bg-gray-600 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                // Apply settings to simulator
                console.log('Applying simulator settings:', simulatorSettings)
                setShowSettings(false)
              }}
              className="px-6 py-3 bg-[#FF6A00] text-white rounded-lg hover:bg-[#FF6A00]/90 transition-colors font-medium shadow-sm"
            >
              Apply Settings
            </button>
          </div>
        </div>
      </Dialog>


    </div>
  )
}

