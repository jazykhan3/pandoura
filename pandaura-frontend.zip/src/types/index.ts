export type ActivityLog = {
  id: string
  message: string
  timestamp: Date
}

export type Connection = {
  id: string
  name: string
  ip: string
  status: 'online' | 'warning' | 'offline'
}

// Enhanced Tag types for industrial PLC systems
export type TagScope = 'global' | 'program' | 'task'
export type TagLifecycle = 'draft' | 'active' | 'deprecated' | 'archived'
export type TagDataType = 'BOOL' | 'INT' | 'DINT' | 'REAL' | 'LREAL' | 'STRING' | 'TIME' | 'ARRAY' | 'UDT' | 'STRUCT'

export type UDTMember = {
  name: string
  type: TagDataType
  udtType?: string // For nested UDTs
  arraySize?: number
  baseType?: string // Base type for arrays
  defaultValue?: any
  description?: string
  members?: UDTMember[] // Support nested structs
}

export type UserDefinedType = {
  id: string
  name: string
  description?: string
  members: UDTMember[]
  createdAt: string
  createdBy: string
  projectId?: string
}

export type TagValidationRule = {
  id: string
  type: 'min' | 'max' | 'range' | 'regex' | 'custom'
  value: any
  message?: string
  severity?: 'error' | 'warning' | 'info'
}

export type TagAlias = {
  id: string
  tagId: string
  alias: string
  vendorAddress?: string
  description?: string
}

export type TagDependency = {
  tagId: string
  tagName: string
  dependsOnTagId?: string
  dependencyType: 'routine' | 'file' | 'hmi' | 'alarm' | 'tag'
  usageType: 'read' | 'write' | 'readwrite'
  location: {
    fileId?: string
    fileName?: string
    routine?: string
    lineNumber?: number
    column?: number
  }
}

export type TagHierarchyNode = {
  id: string
  name: string
  type: 'area' | 'equipment' | 'routine' | 'tag'
  parentId?: string
  tagId?: string
  children?: TagHierarchyNode[]
}

export type Tag = {
  id: string
  name: string
  type: TagDataType
  udtType?: string // Reference to UDT if type is 'UDT'
  value: string | number | boolean | null
  address: string
  lastUpdate: Date
  persist?: boolean
  source?: 'live' | 'shadow' | 'simulator'
  
  // Enhanced features
  scope?: TagScope
  scopeLocked?: boolean
  lifecycle?: TagLifecycle
  hierarchyPath?: string // e.g., "Area1/Equipment2/Routine3"
  area?: string
  equipment?: string
  routine?: string
  
  // Validation
  validationRules?: TagValidationRule[]
  alarmThresholds?: {
    low?: number
    high?: number
    critical?: number
  }
  
  // Permissions
  readOnly?: boolean
  requiresApproval?: boolean
  allowedRoles?: string[]
  
  // Metadata
  metadata?: {
    description?: string
    units?: string
    vendor?: 'rockwell' | 'siemens' | 'beckhoff' | 'neutral'
    imported?: boolean
    version?: number
  }
  
  // Relations
  aliases?: TagAlias[]
  dependencies?: TagDependency[]
  
  // Project reference
  projectId?: string
}

// CSV mapping presets for tag import/export
export type TagCsvFieldKey =
  | 'name'
  | 'type'
  | 'address'
  | 'value'
  | 'area'
  | 'equipment'
  | 'routine'
  | 'description'

export type TagCsvFieldMapping = {
  id: string
  columnName: string
  field: TagCsvFieldKey
  required?: boolean
}

export type TagCsvMappingPreset = {
  id: string
  name: string
  description?: string
  vendor?: 'rockwell' | 'siemens' | 'beckhoff' | 'neutral'
  fieldMappings: TagCsvFieldMapping[]
  version: number
  createdAt: string
  updatedAt: string
  orgKey: string
  workspaceKey: string
}

export type TagImportMapping = {
  sourceTag: string
  targetTag: string
  action: 'create' | 'update' | 'skip' | 'conflict'
  conflicts?: string[]
  udtMapping?: Record<string, string>
}

export type TagRefactoringPreview = {
  tagId: string
  oldName: string
  newName: string
  affectedFiles: {
    fileId: string
    fileName: string
    occurrences: number
    changes: {
      line: number
      oldText: string
      newText: string
    }[]
  }[]
  requiresApproval: boolean
  estimatedImpact: 'low' | 'medium' | 'high'
}

export type BulkTagOperation = {
  id?: string
  operation: 'create' | 'update' | 'delete' | 'rename' | 'copy' | 'move' | 'convert'
  tags?: string[] // tag IDs
  changes?: Record<string, any>[]
  dryRun: boolean
  affectedTags?: number
  affectedFiles?: string[]
  requiresApproval?: boolean
  preview?: {
    successful: number
    failed: number
    warnings: string[]
  }
  status?: 'pending' | 'running' | 'completed' | 'failed'
  createdAt?: string
  completedAt?: string
}

export type LegacyDeploymentLog = {
  id: string
  timestamp: Date
  version: string
  status: 'success' | 'failed' | 'pending'
  changes: number
}

// Milestone 2 types

export type LogicFile = {
  id: string
  name: string
  content: string
  vendor: 'neutral' | 'rockwell' | 'siemens' | 'beckhoff'
  lastModified: string
  author: string
  snapshot?: boolean
  projectId?: string
  readOnly?: boolean
}

export type SyncEventType = 
  | 'TAG_UPDATE' 
  | 'LOGIC_PUSH' 
  | 'HEARTBEAT' 
  | 'CONFLICT'
  | 'CONFLICT_RESOLVED'
  | 'CONNECT'
  | 'DISCONNECT'

export type SyncEvent = {
  id: string
  type: SyncEventType
  timestamp: string
  payload: Record<string, unknown>
  source?: 'live' | 'shadow'
}

export type ValidationError = {
  line: number
  column: number
  severity: 'error' | 'warning' | 'info'
  message: string
}

export type ValidationResult = {
  isValid: boolean
  errors: ValidationError[]
}

export type SimulatorState = {
  isRunning: boolean
  isPaused: boolean
  speed: number
  logs: SimulatorLog[]
  ioValues: Record<string, number | boolean>
  breakpoints: number[]
  currentLine?: number
}

export type SimulatorLog = {
  id: string
  timestamp: string
  message: string
  type: 'info' | 'warning' | 'error' | 'tag_change' | 'drift' | 'execution'
  data?: Record<string, unknown>
}

export type SyncStatus = {
  connected: boolean
  shadowOk: boolean
  liveOk: boolean
  lastSync: string | null
  latency: number
  conflicts: SyncConflict[]
  executionMode?: 'interpreter' | 'stopped' | 'simulation' | 'beremiz'
}

export type SyncConflict = {
  id: string
  tagName: string
  shadowValue: unknown
  liveValue: unknown
  timestamp: string
  resolved: boolean
  type?: 'VALUE_CONFLICT' | 'TYPE_CONFLICT' | 'ACCESS_CONFLICT'
  description?: string
}

export type ChangePreview = {
  type: 'addition' | 'modification' | 'deletion'
  line: number
  oldContent?: string
  newContent?: string
}

// Milestone 3: Versioning Center types

export type BranchStage = 'main' | 'dev' | 'qa' | 'staging' | 'prod'

export type Branch = {
  id: string
  name: string
  stage: BranchStage
  createdAt: string
  createdBy: string
  parentBranch?: string
  isDefault: boolean
  releaseCount?: number // Number of releases in this branch
}

export type BranchWithReleases = Branch & {
  releases: Release[]
  activeRelease?: Release // Currently deployed release
}

export type VersionStatus = 'draft' | 'staged' | 'released'

export type Version = {
  id: string
  version: string
  author: string
  timestamp: string
  filesChanged: number
  checksum: string
  status: VersionStatus
  signed: boolean
  approvals: number
  approvalsRequired: number
  linkedDeploys: number
  branch: string
  stage: BranchStage
  message?: string
  tags?: string[]
}

export type FileChange = {
  id: string
  path: string
  type: 'added' | 'modified' | 'deleted'
  linesAdded: number
  linesDeleted: number
  diff?: string
}

export type VersionDetail = Version & {
  files: FileChange[]
  signature?: string
  signedBy?: string
  signedAt?: string
  metadata?: Record<string, unknown>
}

export type ProjectState = {
  projectId: string
  logicFiles: {
    id: string
    name: string
    content: string
    path: string
  }[]
  tags: Tag[]
  udts: UserDefinedType[]
  configurations: Record<string, any>
  metadata: Record<string, any>
}

export type Snapshot = {
  id: string
  name: string
  versionId: string
  projectState: ProjectState // Complete project state at snapshot time
  createdAt: string
  createdBy: string
  description?: string
  tags?: string[]
  checksum: string // Checksum of project state for integrity
  metadata?: Record<string, any> // Additional metadata including auto-generation info
}

export type Release = {
  id: string
  name: string
  version: string
  snapshotId: string
  branchId: string // Which branch this release belongs to
  stage: BranchStage // Current deployment stage
  createdAt: string
  createdBy: string
  deployedAt?: string // When it was deployed to current stage
  deployedBy?: string // Who deployed it to current stage
  signed: boolean
  signature?: string
  metadata?: Record<string, unknown>
  bundle?: string
  bundleChecksum?: string
  checksumVerified?: boolean
  status: 'active' | 'deprecated' | 'archived'
  tags?: string[]
}

// Enhanced Logic Editor types

export type SymbolType = 'function' | 'program' | 'function_block' | 'variable' | 'udt' | 'constant'

export type Symbol = {
  id: string
  name: string
  type: SymbolType
  dataType?: string
  line: number
  scope: string
  references: number
  children?: Symbol[]
  description?: string
  isUsed: boolean
}

export type LocalHistoryEntry = {
  id: string
  timestamp: string
  content: string
  message?: string
  author: string
}

export type CodeAction = {
  id: string
  title: string
  kind: 'refactor' | 'quickfix' | 'source'
  command: string
  description?: string
}

export type TestCase = {
  id: string
  name: string
  routine: string
  inputs: Record<string, unknown>
  expectedOutputs: Record<string, unknown>
  status: 'pending' | 'running' | 'passed' | 'failed'
  actualOutputs?: Record<string, unknown>
  error?: string
  executionTime?: number
  coverage?: number
  trace?: string[]
}

export type DiagnosticSeverity = 'error' | 'warning' | 'info' | 'hint'

export type SemanticDiagnostic = {
  id: string
  severity: DiagnosticSeverity
  message: string
  line: number
  column: number
  category: 'resource' | 'race_condition' | 'uninitialized' | 'unsafe_io' | 'performance'
  suggestion?: string
}

export type SafetyRule = {
  id: string
  name: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  category: string
  description: string
  violations: Array<{
    line: number
    message: string
    canOverride: boolean
    approved: boolean
  }>
}

export type ReplaceScope = 'current_file' | 'open_files' | 'project'

export type ReplaceMatch = {
  file: string
  fileId?: string
  line: number
  column: number
  matchText: string
  contextBefore: string
  contextAfter: string
  selected: boolean
}

export type CodeLens = {
  line: number
  command: string
  title: string
  args?: unknown[]
}

// Project Management types

export type ConnectionProfile = {
  vendor: 'neutral' | 'rockwell' | 'siemens' | 'beckhoff'
  ip: string
  slot: number
  rack: number
  port: number
}

export type Project = {
  id: string
  name: string
  description?: string
  created_at: string
  last_opened: string
  file_path: string
  connection_profile?: ConnectionProfile
  stats?: {
    logicFiles: number
    tags: number
    versions: number
  }
}

export type CreateProjectRequest = {
  name: string
  description?: string
}

export type CreateProjectResponse = {
  success: boolean
  project?: Project
  error?: string
}

// Deploy Safety Check Types
export type SafetyCheckType = 
  | 'syntax-semantic'
  | 'tag-dependencies'
  | 'critical-overwrites'
  | 'resource-limits'
  | 'race-conditions'
  | 'io-conflicts'
  | 'vendor-export'
  | 'runtime-lock'
  | 'dry-run'
  | 'approval-policy'

export type SafetyCheckSeverity = 'info' | 'warning' | 'error' | 'critical'

export type SafetyCheckStatus = 'pending' | 'running' | 'passed' | 'failed' | 'warning'

export type SafetyCheck = {
  id: string
  type: SafetyCheckType
  name: string
  description: string
  status: SafetyCheckStatus
  severity: SafetyCheckSeverity
  message: string
  details: string[]
  executedAt?: string
  executionTime?: number
  autoFix?: boolean
}

export type SafetyCheckResults = {
  releaseId: string
  snapshotId: string
  projectId: string
  checks: SafetyCheck[]
  overallStatus: 'passed' | 'warning' | 'failed'
  executedAt: string
  executedBy: string
  approvalRequired: boolean
  requiredApprovals: string[]
  blockingIssues: number
  warningIssues: number
  totalFiles: number
  totalTags: number
}

// ============== DEPLOYMENT STRATEGY TYPES ==============

export type DeploymentStrategy = 'atomic' | 'canary' | 'chunked'
export type PatchStrategy = 'quiesce' | 'live'

export interface DeploymentTarget {
  id: string
  name: string
  type: 'plc' | 'hmi' | 'scada' | 'cluster'
  address: string
  runtime: string
  version?: string
  status: 'online' | 'offline' | 'maintenance' | 'locked'
  capabilities: string[]
  cohortId?: string
  priority?: number
  lastDeployment?: string
  healthEndpoint?: string
  canQuiesce: boolean
}

export interface HealthCheck {
  id: string
  name: string
  type: 'script' | 'tag_range' | 'exception_log' | 'resource_usage' | 'custom'
  enabled: boolean
  config: {
    script?: string
    tagName?: string
    minValue?: number
    maxValue?: number
    logPath?: string
    cpuThreshold?: number
    memoryThreshold?: number
    timeout?: number
    retryCount?: number
  }
  thresholds: {
    warning: number
    critical: number
  }
}

export interface DeploymentCohort {
  id: string
  name: string
  fraction: number // Percentage (0-100)
  targets: string[] // Target IDs
  order: number
  healthChecks: string[] // Health check IDs
  waitTime: number // Seconds to wait after deployment
  autoPromote: boolean
}

export interface ChunkBoundary {
  id: string
  type: 'program' | 'controller' | 'io_block' | 'custom'
  name: string
  filePatterns: string[]
  dependencies: string[] // Other chunk IDs this depends on
  priority: number
}

export interface RollbackTrigger {
  id: string
  type: 'health_check' | 'exception_count' | 'tag_limit' | 'resource_usage' | 'manual'
  enabled: boolean
  threshold: number
  watchWindow: number // Minutes
  autoRollback: boolean
  config: {
    healthCheckIds?: string[]
    exceptionPattern?: string
    tagNames?: string[]
    cpuThreshold?: number
    memoryThreshold?: number
  }
}

// Atomic Deploy Configuration
export interface AtomicDeployConfig {
  strategy: 'atomic'
  validateBeforeSwap: boolean
  rollbackOnFailure: boolean
  tempAreaPath: string
  swapTimeout: number // Seconds
  cleanupAfterSuccess: boolean
  preDeployValidation: string[] // Script paths
  postDeployValidation: string[] // Script paths
}

// Canary/Phased Deploy Configuration
export interface CanaryDeployConfig {
  strategy: 'canary'
  cohorts: DeploymentCohort[]
  healthChecks: HealthCheck[]
  globalHealthWindow: number // Minutes
  rollbackOnFailure: boolean
  requireManualPromotion: boolean
  maxConcurrentTargets: number
}

// Large Project Chunking Configuration
export interface ChunkedDeployConfig {
  strategy: 'chunked'
  chunkBoundaries: ChunkBoundary[]
  autoDetectBoundaries: boolean
  maxChunkSize: number // Files per chunk
  dependencyOrdering: boolean
  stageWiseMode: boolean // Force chunk boundaries
  parallelChunks: boolean
  rollbackChunkOnFailure: boolean
}

// Combined deployment configuration
export interface DeploymentConfig {
  id: string
  name: string
  strategy: DeploymentStrategy
  patchStrategy: PatchStrategy
  targets: DeploymentTarget[]
  rollbackTriggers: RollbackTrigger[]
  deployWatchWindow: number // Minutes
  
  // Strategy-specific configs (only one will be populated)
  atomic?: AtomicDeployConfig
  canary?: CanaryDeployConfig
  chunked?: ChunkedDeployConfig
  
  // Common settings
  dryRunFirst: boolean
  requireApproval: boolean
  notificationSettings: {
    onStart: string[]
    onSuccess: string[]
    onFailure: string[]
    onRollback: string[]
  }
}

export interface DeploymentExecution {
  id: string
  deploymentId: string
  configId: string
  status: 'pending' | 'running' | 'paused' | 'completed' | 'failed' | 'rolled_back'
  strategy: DeploymentStrategy
  startTime: string
  endTime?: string
  progress: number // 0-100
  currentPhase: string
  
  // Strategy-specific execution state
  atomicState?: {
    phase: 'staging' | 'validating' | 'swapping' | 'cleanup'
    stagedFiles: string[]
    validationResults: any[]
    swapStartTime?: string
  }
  
  canaryState?: {
    currentCohort: number
    cohortStatus: { [cohortId: string]: 'pending' | 'deploying' | 'monitoring' | 'completed' | 'failed' }
    healthCheckResults: { [checkId: string]: any }
    promotionsPending: string[]
  }
  
  chunkedState?: {
    totalChunks: number
    completedChunks: number
    currentChunk?: string
    chunkStatus: { [chunkId: string]: 'pending' | 'deploying' | 'completed' | 'failed' }
    dependencyGraph: { [chunkId: string]: string[] }
  }
  
  logs: DeploymentLog[]
  rollbacks: RollbackExecution[]
}

export interface DeploymentLog {
  id: string
  timestamp: string
  level: 'info' | 'warning' | 'error' | 'debug'
  message: string
  source: string
  targetId?: string
  cohortId?: string
  chunkId?: string
  metadata?: any
}

export interface RollbackExecution {
  id: string
  deploymentExecutionId: string
  triggeredBy: 'user' | 'automatic'
  trigger: RollbackTrigger | null
  reason: string
  startTime: string
  endTime?: string
  status: 'running' | 'completed' | 'failed'
  snapshotId: string // Snapshot to roll back to
  affectedTargets: string[]
  logs: DeploymentLog[]
}


